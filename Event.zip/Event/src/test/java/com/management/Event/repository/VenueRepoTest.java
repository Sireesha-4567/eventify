package com.management.Event.repository;

import com.management.Event.model.Venue;
import com.management.Event.repositories.VenueRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class VenueRepoTest {

    @Autowired
    private VenueRepo venueRepo;

    private Venue venue1;
    private Venue venue2;
    private Venue venue3;

    @BeforeEach
    void setup() {
        venue1 = new Venue(0, "Harmony Hall", "Chennai", "9999999999", 101);
        venue2 = new Venue(0, "Galaxy Arena", "Chennai", "8888888888", 101);
        venue3 = new Venue(0, "Star Palace", "Mumbai", "7777777777", 102);

        venueRepo.saveAll(List.of(venue1, venue2, venue3));
    }

    @Test
    void testFindByMemberId_ReturnsCorrectVenues() {
        List<Venue> result = venueRepo.findByMemberId(101);
        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(v -> v.getVenueName().equals("Harmony Hall")));
        assertTrue(result.stream().anyMatch(v -> v.getVenueName().equals("Galaxy Arena")));
    }

    @Test
    void testFindByVenuePlace_ReturnsCorrectVenues() {
        List<Venue> result = venueRepo.findByVenuePlace("Chennai");
        assertEquals(2, result.size());
        assertTrue(result.stream().allMatch(v -> v.getVenuePlace().equals("Chennai")));
    }

    @Test
    void testFindByVenuePlace_ReturnsEmptyListForUnknownPlace() {
        List<Venue> result = venueRepo.findByVenuePlace("Delhi");
        assertTrue(result.isEmpty());
    }

    @Test
    void testFindByMemberId_ReturnsEmptyListWhenNoMatch() {
        List<Venue> result = venueRepo.findByMemberId(999);
        assertTrue(result.isEmpty());
    }
}
