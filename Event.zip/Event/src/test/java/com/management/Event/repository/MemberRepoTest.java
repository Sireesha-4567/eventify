package com.management.Event.repository;

import com.management.Event.model.Member;
import com.management.Event.repositories.MemberRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)

class MemberRepoTest {

    @Autowired
    private MemberRepo memberRepo;

    private Member user;
    private Member organizer;

    @BeforeEach
    void setUp() {
        user = new Member(0, "user", "Alice", "Doe", "1234567890", "alice@example.com", "password123");
        organizer = new Member(0, "organizer", "Bob", "Smith", "9876543210", "bob@example.com", "adminpass");

        memberRepo.save(user);
        memberRepo.save(organizer);
    }

    @Test
    void testFindByEmailAndPassword_Valid() {
        Member found = memberRepo.findByEmailAndPassword("alice@example.com", "password123");
        assertNotNull(found);
        assertEquals("Alice", found.getFirstName());
    }

    @Test
    void testFindByEmailAndPassword_Invalid() {
        Member found = memberRepo.findByEmailAndPassword("wrong@example.com", "wrongpass");
        assertNull(found);
    }

    @Test
    void testFindByRole_User() {
        List<Member> users = memberRepo.findByRole("user");
        assertEquals(1, users.size());
        assertEquals("Alice", users.get(0).getFirstName());
    }

    @Test
    void testFindByRole_Organizer() {
        List<Member> organizers = memberRepo.findByRole("organizer");
        assertEquals(1, organizers.size());
        assertEquals("Bob", organizers.get(0).getFirstName());
    }

    @Test
    void testFindByEmail_Exists() {
        Member found = memberRepo.findByEmail("bob@example.com");
        assertNotNull(found);
        assertEquals("organizer", found.getRole());
    }

    @Test
    void testFindByEmail_NotFound() {
        Member found = memberRepo.findByEmail("ghost@example.com");
        assertNull(found);
    }
}
