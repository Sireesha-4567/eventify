package com.management.Event.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.management.Event.model.Event;
import com.management.Event.service.EventService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.any;


import static org.mockito.Mockito.*;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EventController.class)
class EventControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EventService eventService;

    @Autowired
    private ObjectMapper objectMapper;

    private Event sampleEvent() {
        Event event = new Event();
        event.setEventId(1);
        event.setEventName("Tech Conference");
        event.setEventCost(1000);
        event.setVenueId(101);
        return event;
    }

    @Test
    void testAddEvent() throws Exception {
        Event event = sampleEvent();
        when(eventService.addEvent(any(Event.class))).thenReturn(event);

        mockMvc.perform(post("/event/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(event)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eventName").value("Tech Conference"));
    }

    @Test
    void testGetEventById() throws Exception {
        when(eventService.getEvent(1)).thenReturn(sampleEvent());

        mockMvc.perform(get("/event/getEvent/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eventId").value(1));
    }

    @Test
    void testGetEventsByVenueId() throws Exception {
        when(eventService.getEventsByVenueId(101)).thenReturn(List.of(sampleEvent()));

        mockMvc.perform(get("/event/getEvents/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testGetByNameAndVenueId() throws Exception {
        when(eventService.getByNameAndVenueId("Tech Conference", 101)).thenReturn(sampleEvent());

        mockMvc.perform(get("/event/getOne/Tech Conference/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.venueId").value(101));
    }

    @Test
    void testUpdateEvent() throws Exception {
        Event event = sampleEvent();
        when(eventService.updateEvent(any(Event.class))).thenReturn(1);

        mockMvc.perform(put("/event/updateEvent")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(event)))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }

    @Test
    void testDeleteEvent() throws Exception {
        when(eventService.deleteEvent(1)).thenReturn(1);

        mockMvc.perform(delete("/event/deleteEvent/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }
}
