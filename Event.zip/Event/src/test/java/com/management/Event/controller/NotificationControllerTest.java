package com.management.Event.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.management.Event.model.Notification;
import com.management.Event.service.NotificationService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.anyInt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(NotificationController.class)
class NotificationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NotificationService notificationService;

    @Autowired
    private ObjectMapper objectMapper;

    private Notification sampleNotification() {
        Notification n = new Notification();
        n.setNotificationId(1);
        n.setDate("2025-07-08");
        n.setTime("12:45");
        n.setMessage("Your booking is confirmed.");
        n.setMemberId(101);
        return n;
    }

    @Test
    void testGetNotifications() throws Exception {
        Notification notification = sampleNotification();
        when(notificationService.getNotifications(101)).thenReturn(List.of(notification));

        mockMvc.perform(get("/notification/getNotification/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].message").value("Your booking is confirmed."));
    }

    @Test
    void testDeleteNotification() throws Exception {
        when(notificationService.deleteNotification(1)).thenReturn(1);

        mockMvc.perform(delete("/notification/deleteNotification/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }
}
