package com.management.Event.service;

import com.management.Event.model.Equipment;
import com.management.Event.model.Event;
import com.management.Event.model.FoodItem;
import com.management.Event.model.Venue;
import com.management.Event.repositories.EquipmentRepo;
import com.management.Event.repositories.EventRepo;
import com.management.Event.repositories.FoodItemRepo;
import com.management.Event.repositories.VenueRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class VenueServiceImplTest {

    @Mock private VenueRepo venueRepo;
    @Mock private EquipmentRepo equipmentRepo;
    @Mock private FoodItemRepo foodItemRepo;
    @Mock private EventRepo eventRepo;

    @InjectMocks private VenueServiceImpl venueService;

    private Venue venue;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        venue = new Venue(1, "Grand Arena", "Chennai", "9876543210", 202);
    }

    @Test
    void testGetVenuesByOrganizerId() {
        when(venueRepo.findByMemberId(202)).thenReturn(List.of(venue));

        List<Venue> result = venueService.getVenuesByOrganizerId(202);

        assertEquals(1, result.size());
        assertEquals("Grand Arena", result.get(0).getVenueName());
    }

    @Test
    void testGetAllDistinctPlaces() {
        Venue v1 = new Venue(1, "A", "Chennai", "1", 1);
        Venue v2 = new Venue(2, "B", "Bangalore", "2", 2);
        Venue v3 = new Venue(3, "C", "Chennai", "3", 3);

        when(venueRepo.findAll()).thenReturn(List.of(v1, v2, v3));

        List<String> result = venueService.getAllDistinctPlaces();

        assertTrue(result.contains("Chennai"));
        assertTrue(result.contains("Bangalore"));
        assertEquals(2, result.size());
    }

    @Test
    void testGetVenueOfPlace() {
        when(venueRepo.findByVenuePlace("Chennai")).thenReturn(List.of(venue));

        List<Venue> result = venueService.getVenueOfPlace("Chennai");

        assertEquals("Grand Arena", result.get(0).getVenueName());
    }

    @Test
    void testAddVenue() {
        when(venueRepo.save(venue)).thenReturn(venue);

        Venue result = venueService.addVenue(venue);

        assertEquals("Grand Arena", result.getVenueName());
    }

    @Test
    void testGetVenueById() {
        when(venueRepo.findById(1)).thenReturn(Optional.of(venue));

        Venue result = venueService.getVenue(1);

        assertEquals("Chennai", result.getVenuePlace());
    }

    @Test
    void testGetAllVenues() {
        when(venueRepo.findAll()).thenReturn(List.of(venue));

        List<Venue> result = venueService.getVenues();

        assertEquals(1, result.size());
        assertEquals("Grand Arena", result.get(0).getVenueName());
    }

    @Test
    void testUpdateVenue() {
        Venue updated = new Venue(1, "Updated Arena", "Mumbai", "9999999999", 202);

        when(venueRepo.findById(1)).thenReturn(Optional.of(venue));
        when(venueRepo.save(any(Venue.class))).thenReturn(updated);

        int result = venueService.updateVenue(updated);

        assertEquals(1, result);
        verify(venueRepo).save(any(Venue.class));
    }

    @Test
    void testDeleteVenueWithDependencies() {
        FoodItem f = new FoodItem(1, "Veg", 100, 1);
        Event e = new Event(1, "Conference", 5000, 1);
        Equipment eq = new Equipment(1, "Mic", 800, 1);

        when(foodItemRepo.findByVenueId(1)).thenReturn(List.of(f));
        when(eventRepo.findByVenueId(1)).thenReturn(List.of(e));
        when(equipmentRepo.findByVenueId(1)).thenReturn(List.of(eq));
        doNothing().when(venueRepo).deleteById(1);

        int result = venueService.deleteVenue(1);

        assertEquals(1, result);
        verify(foodItemRepo).delete(f);
        verify(eventRepo).delete(e);
        verify(equipmentRepo).delete(eq);
        verify(venueRepo).deleteById(1);
    }
}
