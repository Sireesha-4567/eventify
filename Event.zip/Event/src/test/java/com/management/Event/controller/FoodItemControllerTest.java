package com.management.Event.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.management.Event.model.FoodItem;
import com.management.Event.service.FoodItemService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(FoodItemController.class)
class FoodItemControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FoodItemService foodItemService;

    @Autowired
    private ObjectMapper objectMapper;

    private FoodItem sampleFoodItem() {
        FoodItem food = new FoodItem();
        food.setFoodItemId(1);
        food.setFoodItemName("Paneer Tikka");
        food.setFoodItemCost(250);
        food.setVenueId(101);
        return food;
    }

    @Test
    void testAddFoodItem() throws Exception {
        FoodItem food = sampleFoodItem();
        when(foodItemService.addFoodItem(any(FoodItem.class))).thenReturn(food);

        mockMvc.perform(post("/foodItem/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(food)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.foodItemName").value("Paneer Tikka"))
                .andExpect(jsonPath("$.foodItemCost").value(250));
    }

    @Test
    void testGetFoodItemsByVenueId() throws Exception {
        when(foodItemService.getFoodItemsByVenueId(101)).thenReturn(List.of(sampleFoodItem()));

        mockMvc.perform(get("/foodItem/getFoodItems/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].foodItemId").value(1));
    }

    @Test
    void testGetFoodItemById() throws Exception {
        when(foodItemService.getFoodItem(1)).thenReturn(sampleFoodItem());

        mockMvc.perform(get("/foodItem/getFoodItem/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.foodItemName").value("Paneer Tikka"));
    }

    @Test
    void testUpdateFoodItem() throws Exception {
        FoodItem food = sampleFoodItem();
        when(foodItemService.updateFoodItem(any(FoodItem.class))).thenReturn(1);

        mockMvc.perform(put("/foodItem/updateFoodItem")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(food)))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }

    @Test
    void testDeleteFoodItem() throws Exception {
        when(foodItemService.deleteFoodItem(1)).thenReturn(1);

        mockMvc.perform(delete("/foodItem/deleteFoodItem/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }
}
