package com.management.Event.repository;

import com.management.Event.model.Equipment;
import com.management.Event.repositories.EquipmentRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class EquipmentRepoTest {

    @Autowired
    private EquipmentRepo equipmentRepo;

    private Equipment eq1;
    private Equipment eq2;
    private Equipment eq3;

    @BeforeEach
    void setUp() {
        eq1 = new Equipment(0, "Speakers", 1500, 101);
        eq2 = new Equipment(0, "Mic", 500, 101);
        eq3 = new Equipment(0, "Projector", 2000, 102);

        equipmentRepo.saveAll(List.of(eq1, eq2, eq3));
    }

    @Test
    void testFindByVenueId_MultipleResults() {
        List<Equipment> result = equipmentRepo.findByVenueId(101);
        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(e -> e.getEquipmentName().equals("Speakers")));
        assertTrue(result.stream().anyMatch(e -> e.getEquipmentName().equals("Mic")));
    }

    @Test
    void testFindByVenueId_SingleResult() {
        List<Equipment> result = equipmentRepo.findByVenueId(102);
        assertEquals(1, result.size());
        assertEquals("Projector", result.get(0).getEquipmentName());
    }

    @Test
    void testFindByVenueId_NoResults() {
        List<Equipment> result = equipmentRepo.findByVenueId(999);
        assertTrue(result.isEmpty());
    }
}
