package com.management.Event.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.management.Event.model.Member;
import com.management.Event.service.MemberService;
import com.management.Event.service.NotificationService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.Mockito.*;


@WebMvcTest(MemberController.class)
public class MemberControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MemberService memberService;

    @MockBean
    private NotificationService notificationService;

    @Autowired
    private ObjectMapper objectMapper;

    private Member mockMember() {
        Member m = new Member();
        m.setMemberId(1);
        m.setFirstName("John");
        m.setLastName("Doe");
        m.setPhoneNumber("1234567890");
        m.setEmail("john@example.com");
        m.setPassword("secret123");
        m.setRole("USER");
        return m;
    }

    @Test
    void testAddMember() throws Exception {
        when(memberService.addMember(any(Member.class))).thenReturn(mockMember());
 
        mockMvc.perform(post("/member/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(mockMember())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("john@example.com"))
                .andExpect(jsonPath("$.firstName").value("John"));
 
        // Optional: verify the notification was triggered
        verify(notificationService).notificationOnRegistration(any(Member.class));
    }
 

    @Test
    void testAuthenticate() throws Exception {
        Member member = mockMember();

        Mockito.when(memberService.Authenticate("john@example.com", "secret123"))
                .thenReturn(member);

        mockMvc.perform(get("/member/john@example.com/secret123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName", is("John")));
    }

    @Test
    void testGetMember() throws Exception {
        Member member = mockMember();

        Mockito.when(memberService.getMember(1)).thenReturn(member);

        mockMvc.perform(get("/member/getMember/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.lastName", is("Doe")));
    }

    @Test
    void testUpdateMember_shouldFailDueToInvalidPathVariable() throws Exception {
        String serializedMember = objectMapper.writeValueAsString(mockMember());

        mockMvc.perform(put("/member/updateMember/{member}", serializedMember)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }



    @Test
    void testDeleteMember() throws Exception {
        Mockito.when(memberService.deleteMember(1)).thenReturn(1);

        mockMvc.perform(delete("/member/deleteMember/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }

    @Test
    void testGetAllUsers() throws Exception {
        List<Member> members = List.of(mockMember());

        Mockito.when(memberService.getAllUsers()).thenReturn(members);

        mockMvc.perform(get("/member/getAllUsers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(1)))
                .andExpect(jsonPath("$[0].email", is("john@example.com")));
    }

    @Test
    void testGetAllOrganizers() throws Exception {
        List<Member> organizers = List.of(mockMember());

        Mockito.when(memberService.getAllMembers()).thenReturn(organizers);

        mockMvc.perform(get("/member/getAllOrganizers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(1)))
                .andExpect(jsonPath("$[0].role", is("USER")));
    }
}
