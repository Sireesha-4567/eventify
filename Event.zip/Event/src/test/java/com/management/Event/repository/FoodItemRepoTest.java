package com.management.Event.repository;

import com.management.Event.model.FoodItem;
import com.management.Event.repositories.FoodItemRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class FoodItemRepoTest {

    @Autowired
    private FoodItemRepo foodItemRepo;

    private FoodItem item1;
    private FoodItem item2;
    private FoodItem item3;

    @BeforeEach
    void setUp() {
        item1 = new FoodItem(0, "Paneer Tikka", 250, 101);
        item2 = new FoodItem(0, "Veg Biryani", 200, 101);
        item3 = new FoodItem(0, "Chocolate Mousse", 180, 102);

        foodItemRepo.save(item1);
        foodItemRepo.save(item2);
        foodItemRepo.save(item3);
    }

    @Test
    void testFindByVenueId_ExistingVenue() {
        List<FoodItem> items = foodItemRepo.findByVenueId(101);
        assertEquals(2, items.size());
        assertTrue(items.stream().anyMatch(f -> f.getFoodItemName().equals("Paneer Tikka")));
        assertTrue(items.stream().anyMatch(f -> f.getFoodItemName().equals("Veg Biryani")));
    }

    @Test
    void testFindByVenueId_SingleResult() {
        List<FoodItem> items = foodItemRepo.findByVenueId(102);
        assertEquals(1, items.size());
        assertEquals("Chocolate Mousse", items.get(0).getFoodItemName());
    }

    @Test
    void testFindByVenueId_NoResults() {
        List<FoodItem> items = foodItemRepo.findByVenueId(999);
        assertTrue(items.isEmpty());
    }
}
