package com.management.Event.service;

import com.management.Event.model.*;
import com.management.Event.repositories.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookingServiceImplTest {

    @Mock private BookingRepo bookingRepo;
    @Mock private MemberRepo memberRepo;
    @Mock private FoodItemRepo foodItemRepository;
    @Mock private EquipmentRepo equipmentRepo;
    @Mock private EventRepo eventRepo;
    @Mock private VenueRepo venueRepo;

    @InjectMocks private BookingServiceImpl bookingService;

    private Booking booking;
    private Member member;
    private Venue venue;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        member = new Member(1, "user", "John", "Doe", "9999999999", "john@example.com", "secret");
        venue = new Venue(101, "Banquet Hall", "Chennai", "1234567890", 1);

        booking = new Booking();
        booking.setBookingId(1);
        booking.setDate(Date.valueOf(LocalDate.now().plusDays(3)));
        booking.setGuestCount(100);
        booking.setEventName("Conference");
        booking.setVenueId(101);
        booking.setMemberId(1);
        booking.setPaymentStatus("Processed");
        booking.setSelectedFoodItems("1,2");
        booking.setSelectedEquipments("3");
    }

    @Test
    void testIsAvailableReturnsTrue_WhenDateNotBooked() {
        when(venueRepo.findById(101)).thenReturn(Optional.of(venue));
        when(bookingRepo.findBookingByVenueAndPaymentStatusOrderByDate(any(), eq("Processed")))
                .thenReturn(Collections.emptyList());

        assertTrue(bookingService.isAvailable(booking));
    }

    @Test
    void testIsAvailableReturnsFalse_WhenDateIsAlreadyBooked() {
        when(venueRepo.findById(101)).thenReturn(Optional.of(venue));
        Booking existing = new Booking();
        existing.setDate(booking.getDate());
        when(bookingRepo.findBookingByVenueAndPaymentStatusOrderByDate(any(), eq("Processed")))
                .thenReturn(List.of(existing));

        assertFalse(bookingService.isAvailable(booking));
    }

    @Test
    void testIsAvailableForPaymentTrue_WhenBookingDateNotDuplicated() {
        Booking existing = new Booking();
        existing.setBookingId(1);
        existing.setDate(booking.getDate());
        existing.setVenue(venue);
        when(bookingRepo.findById(1)).thenReturn(Optional.of(existing));
        when(venueRepo.findById(101)).thenReturn(Optional.of(venue));
        when(bookingRepo.findBookingByVenueAndPaymentStatusOrderByDate(any(), eq("Processed")))
                .thenReturn(Collections.emptyList());

        assertTrue(bookingService.isAvailableForPayment(1));
    }

    @Test
    void testBookingDetailConversion() {
        booking.setMember(member);
        booking.setVenue(venue);

        // Stub first — before calling the service
        when(bookingRepo.findById(1)).thenReturn(Optional.of(booking));

        // Now call the method under test
        BookingDetail detail = bookingService.bookingDetail(1);

        assertNotNull(detail);
        assertEquals("John", detail.getFirstName());
        assertEquals("Banquet Hall", detail.getVenueName());
    }


    @Test
    void testGetUpcomingBookedDates_ReturnsOnlyFutureDates() {
        booking.setDate(Date.valueOf(LocalDate.now().plusDays(2)));

        when(venueRepo.findById(101)).thenReturn(Optional.of(venue));
        when(bookingRepo.findBookingByVenueAndPaymentStatusOrderByDate(any(), eq("Processed")))
                .thenReturn(List.of(booking));

        List<Date> result = bookingService.getUpcomingBookedDates(101);

        assertEquals(1, result.size());
        assertTrue(result.get(0).after(Date.valueOf(LocalDate.now().minusDays(1))));
    }

    @Test
    void testPaymentSuccess_UpdatesBooking() {
        Booking unpaid = new Booking();
        unpaid.setBookingId(1);
        unpaid.setDate(Date.valueOf(LocalDate.now().plusDays(1)));
        unpaid.setVenue(venue);
        unpaid.setPaymentStatus("Pending");

        when(bookingRepo.findById(1)).thenReturn(Optional.of(unpaid));
        when(venueRepo.findById(101)).thenReturn(Optional.of(venue));
        when(bookingRepo.findBookingByVenueAndPaymentStatusOrderByDate(any(), eq("Processed")))
                .thenReturn(Collections.emptyList());

        int result = bookingService.payment(1);
        assertEquals(1, result);
        assertEquals("Processed", unpaid.getPaymentStatus());
    }

    @Test
    void testDeleteBooking_Success() {
        doNothing().when(bookingRepo).deleteById(1);
        assertEquals(1, bookingService.deleteBooking(1));
        verify(bookingRepo).deleteById(1);
    }

    @Test
    void testCheckActiveBookings_WhenUpcomingProcessedBookingsExist() {
        booking.setPaymentStatus("Processed");
        booking.setDate(Date.valueOf(LocalDate.now().plusDays(1)));
        booking.setVenue(venue);
        booking.setMember(member);

        when(venueRepo.findById(101)).thenReturn(Optional.of(venue));
        when(bookingRepo.findByVenue(venue)).thenReturn(List.of(booking));

        int result = bookingService.checkActiveBookings(101);
        assertEquals(1, result);
    }
}
