package com.management.Event.repository;

import com.management.Event.model.Notification;
import com.management.Event.repositories.NotificationRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class NotificationRepoTest {

    @Autowired
    private NotificationRepo notificationRepo;

    private Notification n1;
    private Notification n2;
    private Notification n3;

    @BeforeEach
    void setUp() {
        n1 = new Notification(0, "10:00", "2025-07-07", "Welcome Aboard!", 101);
        n2 = new Notification(0, "11:30", "2025-07-07", "Your booking has been confirmed.", 101);
        n3 = new Notification(0, "12:45", "2025-07-07", "Payment received successfully.", 102);

        notificationRepo.saveAll(List.of(n1, n2, n3));
    }

    @Test
    void testFindByMemberId_ValidUser() {
        List<Notification> result = notificationRepo.findByMemberId(101);
        assertEquals(2, result.size());
        assertTrue(result.stream().allMatch(n -> n.getMemberId() == 101));
    }

    @Test
    void testFindByMemberId_SingleNotification() {
        List<Notification> result = notificationRepo.findByMemberId(102);
        assertEquals(1, result.size());
        assertEquals("Payment received successfully.", result.get(0).getMessage());
    }

    @Test
    void testFindByMemberId_NoResult() {
        List<Notification> result = notificationRepo.findByMemberId(999);
        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveNotification_GeneratesId() {
        Notification newNotification = new Notification(0, "13:00", "2025-07-07", "You have a new message.", 103);
        Notification saved = notificationRepo.save(newNotification);
        assertNotEquals(0, saved.getNotificationId());
    }
}
