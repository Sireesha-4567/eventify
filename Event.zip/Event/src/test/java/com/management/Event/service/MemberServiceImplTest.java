package com.management.Event.service;

import com.management.Event.exception.ResourceNotFoundException;
import com.management.Event.model.Member;
import com.management.Event.repositories.MemberRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Optional;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class MemberServiceImplTest {

    @Mock
    private MemberRepo memberRepo;

    @InjectMocks
    private MemberServiceImpl memberService;

    private Member sampleMember;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        sampleMember = new Member(1, "user", "Alice", "Smith", "9999999999", "alice@example.com", "secret");
    }

    @Test
    void testAddMember() {
        when(memberRepo.save(sampleMember)).thenReturn(sampleMember);
        Member result = memberService.addMember(sampleMember);
        assertEquals("Alice", result.getFirstName());
    }

    @Test
    void testAuthenticate_Success() throws ResourceNotFoundException {
        when(memberRepo.findByEmailAndPassword("alice@example.com", "secret")).thenReturn(sampleMember);
        Member result = memberService.Authenticate("alice@example.com", "secret");
        assertEquals("Smith", result.getLastName());
    }

    @Test
    void testAuthenticate_Failure_ThrowsException() {
        when(memberRepo.findByEmailAndPassword("invalid@example.com", "wrong")).thenThrow(new RuntimeException());
        assertThrows(ResourceNotFoundException.class, () ->
                memberService.Authenticate("invalid@example.com", "wrong"));
    }

    @Test
    void testGetMember() {
        when(memberRepo.findById(1)).thenReturn(Optional.of(sampleMember));
        Member result = memberService.getMember(1);
        assertEquals("user", result.getRole());
    }

    @Test
    void testUpdateMember() {
        Member updated = new Member(1, "user", "Bob", "Jones", "8888888888", "bob@example.com", "newpass");
        when(memberRepo.findById(1)).thenReturn(Optional.of(sampleMember));
        when(memberRepo.save(any(Member.class))).thenReturn(updated);

        int result = memberService.updateMember(updated);
        assertEquals(1, result);
    }

    @Test
    void testDeleteMember() {
        doNothing().when(memberRepo).deleteById(1);
        int result = memberService.deleteMember(1);
        assertEquals(1, result);
        verify(memberRepo, times(1)).deleteById(1);
    }

    @Test
    void testGetAllUsers() {
        when(memberRepo.findByRole("user")).thenReturn(Arrays.asList(sampleMember));
        List<Member> users = memberService.getAllUsers();
        assertEquals(1, users.size());
        assertEquals("Alice", users.get(0).getFirstName());
    }

    @Test
    void testGetAllOrganizers() {
        Member org = new Member(2, "organizer", "Eve", "Wills", "7777777777", "eve@example.com", "pass123");
        when(memberRepo.findByRole("organizer")).thenReturn(List.of(org));

        List<Member> organizers = memberService.getAllMembers();
        assertEquals(1, organizers.size());
        assertEquals("Eve", organizers.get(0).getFirstName());
    }
}
