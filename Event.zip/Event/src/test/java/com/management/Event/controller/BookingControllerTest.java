package com.management.Event.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.management.Event.model.Booking;
import com.management.Event.model.BookingDetail;
import com.management.Event.service.BookingService;
import com.management.Event.service.NotificationService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.sql.Date;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookingController.class)
class BookingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookingService bookingService;

    @MockBean
    private NotificationService notificationService;

    @Autowired
    private ObjectMapper objectMapper;

    private Booking sampleBooking() {
        Booking b = new Booking();
        b.setBookingId(1);
        b.setDate(Date.valueOf("2025-07-15"));
        b.setEventName("Wedding");
        b.setVenueId(101);
        b.setMemberId(202);
        b.setGuestCount(150);
        b.setTotalCost(50000);
        b.setPaymentStatus("Pending");
        return b;
    }

    private BookingDetail sampleBookingDetail() {
        BookingDetail d = new BookingDetail();
        d.setBookingId(1);
        d.setVenueId(101);
        d.setMemberId(202);
        d.setEventName("Wedding");
        d.setGuestCount(150);
        d.setTotalCost(50000);
        d.setPaymentStatus("Pending");
        d.setVenueName("Grand Hall");
        d.setFirstName("Alice");
        d.setEmail("alice@example.com");
        return d;
    }

    @Test
    void testAddBooking_WhenAvailable_Returns1() throws Exception {
        when(bookingService.isAvailable(any(Booking.class))).thenReturn(true);

        mockMvc.perform(post("/booking/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(sampleBooking())))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }

    @Test
    void testAddBooking_WhenUnavailable_Returns0() throws Exception {
        when(bookingService.isAvailable(any(Booking.class))).thenReturn(false);

        mockMvc.perform(post("/booking/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(sampleBooking())))
                .andExpect(status().isOk())
                .andExpect(content().string("0"));
    }

    @Test
    void testGetBookingById() throws Exception {
        when(bookingService.getBooking(1)).thenReturn(sampleBooking());

        mockMvc.perform(get("/booking/getBooking/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eventName").value("Wedding"));
    }

    @Test
    void testGetAllBookings() throws Exception {
        when(bookingService.getBookings()).thenReturn(List.of(sampleBookingDetail()));

        mockMvc.perform(get("/booking/getAllBookings"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }

    @Test
    void testGetBookingsByUserId() throws Exception {
        when(bookingService.getBookingsByUserId(202)).thenReturn(List.of(sampleBookingDetail()));

        mockMvc.perform(get("/booking/bookingsByUserId/202"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].firstName").value("Alice"));
    }

    @Test
    void testBookingDetail() throws Exception {
        when(bookingService.bookingDetail(1)).thenReturn(sampleBookingDetail());

        mockMvc.perform(get("/booking/bookingDetail/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.venueName").value("Grand Hall"));
    }

    @Test
    void testDoPayment_WhenAvailable_Returns1() throws Exception {
        when(bookingService.isAvailableForPayment(1)).thenReturn(true);

        mockMvc.perform(get("/booking/doPayment/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }


    @Test
    void testDoPayment_WhenUnavailable_Returns0() throws Exception {
        when(bookingService.isAvailableForPayment(1)).thenReturn(false);

        mockMvc.perform(get("/booking/doPayment/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("0"));
    }

    @Test
    void testDeleteBooking() throws Exception {
        when(bookingService.deleteBooking(1)).thenReturn(1);

        mockMvc.perform(delete("/booking/deleteBooking/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }

    @Test
    void testUpcomingBookings() throws Exception {
        when(bookingService.getBookingDetailByOrganizerId(301, "Future")).thenReturn(List.of(sampleBookingDetail()));

        mockMvc.perform(get("/booking/upcomingBookings/301"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].paymentStatus").value("Pending"));
    }

    @Test
    void testPreviousBookings() throws Exception {
        when(bookingService.getBookingDetailByOrganizerId(301, "Past")).thenReturn(List.of());

        mockMvc.perform(get("/booking/previousBookings/301"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    void testGetDates() throws Exception {
        when(bookingService.getUpcomingBookedDates(101)).thenReturn(List.of(Date.valueOf("2025-07-15")));

        mockMvc.perform(get("/booking/getDates/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").value("2025-07-15"));
    }

    @Test
    void testCheckActiveBookings() throws Exception {
        when(bookingService.checkActiveBookings(101)).thenReturn(1);

        mockMvc.perform(get("/booking/checkActiveBookings/101"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }
}
