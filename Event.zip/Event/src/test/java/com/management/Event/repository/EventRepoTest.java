package com.management.Event.repository;

import com.management.Event.model.Event;
import com.management.Event.repositories.EventRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)

class EventRepoTest {

    @Autowired
    private EventRepo eventRepo;

    private Event event1;
    private Event event2;
    private Event event3;

    @BeforeEach
    void setUp() {
        event1 = new Event(0, "Conference", 5000, 101);
        event2 = new Event(0, "Wedding", 8000, 101);
        event3 = new Event(0, "Concert", 7000, 102);

        eventRepo.save(event1);
        eventRepo.save(event2);
        eventRepo.save(event3);
    }

    @Test
    void testFindByVenueId_ReturnsCorrectEvents() {
        List<Event> result = eventRepo.findByVenueId(101);
        assertEquals(2, result.size());

        List<String> eventNames = result.stream().map(Event::getEventName).toList();
        assertTrue(eventNames.contains("Conference"));
        assertTrue(eventNames.contains("Wedding"));
    }

    @Test
    void testFindByEventNameAndVenueId_Exists() {
        Event result = eventRepo.findByEventNameAndVenueId("Concert", 102);
        assertNotNull(result);
        assertEquals(7000, result.getEventCost());
    }

    @Test
    void testFindByEventNameAndVenueId_NotFound() {
        Event result = eventRepo.findByEventNameAndVenueId("Nonexistent", 101);
        assertNull(result);
    }
}
