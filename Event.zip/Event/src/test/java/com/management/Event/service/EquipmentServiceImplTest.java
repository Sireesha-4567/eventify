package com.management.Event.service;

import com.management.Event.model.Equipment;
import com.management.Event.repositories.EquipmentRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EquipmentServiceImplTest {

    @Mock
    private EquipmentRepo equipmentRepo;

    @InjectMocks
    private EquipmentServiceImpl equipmentService;

    private Equipment equipment;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        equipment = new Equipment(1, "Speakers", 1500, 101);
    }

    @Test
    void testGetEquipmentsByVenueId() {
        when(equipmentRepo.findByVenueId(101)).thenReturn(List.of(equipment));

        List<Equipment> result = equipmentService.getEquipmentsByVenueId(101);

        assertEquals(1, result.size());
        assertEquals("Speakers", result.get(0).getEquipmentName());
    }

    @Test
    void testAddEquipment() {
        when(equipmentRepo.save(equipment)).thenReturn(equipment);

        Equipment result = equipmentService.addEquipment(equipment);

        assertNotNull(result);
        assertEquals(1500, result.getEquipmentCost());
    }

    @Test
    void testGetEquipmentById() {
        when(equipmentRepo.findById(1)).thenReturn(Optional.of(equipment));

        Equipment result = equipmentService.getEquipment(1);

        assertNotNull(result);
        assertEquals("Speakers", result.getEquipmentName());
    }

    @Test
    void testUpdateEquipment() {
        Equipment updated = new Equipment(1, "Amplifier", 1800, 101);

        when(equipmentRepo.findById(1)).thenReturn(Optional.of(equipment));
        when(equipmentRepo.save(any(Equipment.class))).thenReturn(updated);

        int result = equipmentService.updateEquipment(updated);

        assertEquals(1, result);
        verify(equipmentRepo).save(any(Equipment.class));
    }

    @Test
    void testDeleteEquipment() {
        doNothing().when(equipmentRepo).deleteById(1);

        int result = equipmentService.deleteEquipment(1);

        assertEquals(1, result);
        verify(equipmentRepo).deleteById(1);
    }
}
