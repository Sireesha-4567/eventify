package com.management.Event.repository;

import com.management.Event.model.*;
import com.management.Event.repositories.BookingRepo;
import com.management.Event.repositories.MemberRepo;
import com.management.Event.repositories.VenueRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class BookingRepoTest {

    @Autowired private BookingRepo bookingRepo;
    @Autowired private VenueRepo venueRepo;
    @Autowired private MemberRepo memberRepo;

    private Member member;
    private Venue venue;

    @BeforeEach
    void setup() {
        member = new Member(0, "user", "Alice", "Wills", "1234567890", "alice@example.com", "password");
        venue = new Venue(0, "Green Garden", "Chennai", "9998887777", 0);
        memberRepo.save(member);
        venueRepo.save(venue);

        Booking b1 = new Booking();
        b1.setDate(Date.valueOf(LocalDate.now().plusDays(1)));
        b1.setEventName("Conference");
        b1.setPaymentStatus("Processed");
        b1.setMember(member);
        b1.setVenue(venue);

        Booking b2 = new Booking();
        b2.setDate(Date.valueOf(LocalDate.now().plusDays(2)));
        b2.setEventName("Seminar");
        b2.setPaymentStatus("Pending");
        b2.setMember(member);
        b2.setVenue(venue);

        bookingRepo.save(b1);
        bookingRepo.save(b2);
    }

    @Test
    void testFindByVenue() {
        List<Booking> results = bookingRepo.findByVenue(venue);
        assertEquals(2, results.size());
    }

    @Test
    void testFindBookingByVenueAndPaymentStatusOrderByDate() {
        List<Booking> results = bookingRepo.findBookingByVenueAndPaymentStatusOrderByDate(venue, "Processed");
        assertEquals(1, results.size());
        assertEquals("Conference", results.get(0).getEventName());
    }

    @Test
    void testFindByMember() {
        List<Booking> results = bookingRepo.findByMember(member);
        assertEquals(2, results.size());
    }

    @Test
    void testNoBookingsForNonexistentMember() {
        Member ghost = new Member(0, "user", "Ghost", "User", "0000000000", "ghost@example.com", "ghostpass");
        memberRepo.save(ghost);
        List<Booking> result = bookingRepo.findByMember(ghost);
        assertTrue(result.isEmpty());
    }
}
