package com.management.Event.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.management.Event.model.Equipment;
import com.management.Event.service.EquipmentService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EquipmentController.class)
class EquipmentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EquipmentService equipmentService;

    @Autowired
    private ObjectMapper objectMapper;

    private Equipment sampleEquipment() {
        Equipment eq = new Equipment();
        eq.setEquipmentId(1);
        eq.setEquipmentName("Projector");
        eq.setEquipmentCost(1500);
        eq.setVenueId(101);
        return eq;
    }

    @Test
    void testAddEquipment() throws Exception {
        Equipment equipment = sampleEquipment();
        when(equipmentService.addEquipment(any(Equipment.class))).thenReturn(equipment);

        mockMvc.perform(post("/equipment/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(equipment)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.equipmentName").value("Projector"));
    }

    @Test
    void testGetEquipmentById() throws Exception {
        when(equipmentService.getEquipment(1)).thenReturn(sampleEquipment());

        mockMvc.perform(get("/equipment/getEquipment/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.equipmentCost").value(1500));
    }

    @Test
    void testGetEquipmentsByVenueId() throws Exception {
        when(equipmentService.getEquipmentsByVenueId(101)).thenReturn(List.of(sampleEquipment()));

        mockMvc.perform(get("/equipment/getEquipments/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].equipmentId").value(1));
    }

    @Test
    void testUpdateEquipment() throws Exception {
        Equipment equipment = sampleEquipment();
        when(equipmentService.updateEquipment(any(Equipment.class))).thenReturn(1);

        mockMvc.perform(put("/equipment/updateEquipment")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(equipment)))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }

    @Test
    void testDeleteEquipment() throws Exception {
        when(equipmentService.deleteEquipment(1)).thenReturn(1);

        mockMvc.perform(delete("/equipment/deleteEquipment/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }
}
