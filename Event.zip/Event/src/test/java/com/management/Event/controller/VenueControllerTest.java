package com.management.Event.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.management.Event.model.Venue;
import com.management.Event.service.NotificationService;
import com.management.Event.service.VenueService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import static org.mockito.ArgumentMatchers.any;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(VenueController.class)
class VenueControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VenueService venueService;

    @MockBean
    private NotificationService notificationService;

    @Autowired
    private ObjectMapper objectMapper;

    private Venue sampleVenue() {
        Venue venue = new Venue();
        venue.setVenueId(1);
        venue.setVenueName("Grand Convention");
        venue.setVenuePlace("Chennai");
        venue.setVenueContact("9845671234");
        venue.setMemberId(101);
        return venue;
    }

    @Test
    void testGetVenuesByOrganizerId() throws Exception {
        when(venueService.getVenuesByOrganizerId(101)).thenReturn(List.of(sampleVenue()));

        mockMvc.perform(get("/venue/organizer/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].venueName").value("Grand Convention"));
    }

    @Test
    void testGetAllDistinctPlaces() throws Exception {
        when(venueService.getAllDistinctPlaces()).thenReturn(List.of("Chennai", "Bangalore"));

        mockMvc.perform(get("/venue/places"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[1]").value("Bangalore"));
    }

    @Test
    void testGetVenueOfPlace() throws Exception {
        when(venueService.getVenueOfPlace("Chennai")).thenReturn(List.of(sampleVenue()));

        mockMvc.perform(get("/venue/getVenues/Chennai"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].venuePlace").value("Chennai"));
    }
    @Test
    void testAddVenue() throws Exception {
        Venue venue = sampleVenue();

        when(venueService.addVenue(org.mockito.ArgumentMatchers.any(Venue.class))).thenReturn(venue);

        mockMvc.perform(post("/venue/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(venue)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.venueContact").value("9845671234"));
    }

    @Test
    void testGetVenueById() throws Exception {
        when(venueService.getVenue(1)).thenReturn(sampleVenue());

        mockMvc.perform(get("/venue/getVenue/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.venueId").value(1));
    }

    @Test
    void testGetAllVenues() throws Exception {
        when(venueService.getVenues()).thenReturn(List.of(sampleVenue()));

        mockMvc.perform(get("/venue/getVenues"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].venueName").value("Grand Convention"));
    }

    @Test
    void testUpdateVenue() throws Exception {
        Venue venue = sampleVenue();
        when(venueService.updateVenue(any(Venue.class))).thenReturn(1);

        mockMvc.perform(put("/venue/updateVenue")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(venue)))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }

    @Test
    void testDeleteVenue() throws Exception {
        when(venueService.deleteVenue(1)).thenReturn(1);

        mockMvc.perform(delete("/venue/deleteVenue/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("1"));
    }
}
