package com.management.Event.service;

import com.management.Event.model.*;
import com.management.Event.repositories.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class NotificationServiceImplTest {

    @Mock private MemberRepo memberRepo;
    @Mock private NotificationRepo notificationRepo;
    @Mock private BookingService bookingService;
    @Mock private VenueRepo venueRepo;

    @InjectMocks private NotificationServiceImpl notificationService;

    private Member userMember;
    private Member orgMember;
    private Venue venue;
    private Booking booking;
    private BookingDetail detail;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        userMember = new Member(1, "user", "Alice", "Wills", "9999999999", "alice@example.com", "pass");
        orgMember = new Member(2, "organizer", "Bob", "Smith", "8888888888", "bob@example.com", "secret");

        venue = new Venue(10, "Expo Hall", "Chennai", "7777777777", orgMember.getMemberId());

        booking = new Booking();
        booking.setBookingId(1001);
        booking.setMemberId(userMember.getMemberId());

        detail = new BookingDetail();
        detail.setBookingId(1001);
        detail.setMemberId(userMember.getMemberId());
        detail.setFirstName("Alice");
        detail.setLastName("Wills");
        detail.setVenueId(10);
        detail.setVenueName("Expo Hall");
        detail.setVenuePlace("Chennai");
        detail.setEventName("Conference");
        detail.setTotalCost(5000);
        detail.setDate(java.sql.Date.valueOf("2025-08-01"));
    }

    @Test
    void testNotificationOnUserRegistration() {
        when(memberRepo.findByEmail("alice@example.com")).thenReturn(userMember);
        int result = notificationService.notificationOnRegistration(userMember);
        assertEquals(1, result);
        verify(notificationRepo).save(any(Notification.class));
    }

    @Test
    void testNotificationOnOrganizerRegistration() {
        when(memberRepo.findByEmail("bob@example.com")).thenReturn(orgMember);
        int result = notificationService.notificationOnRegistration(orgMember);
        assertEquals(1, result);
        verify(notificationRepo).save(any(Notification.class));
    }

    @Test
    void testNotifyOnBooking() {
        int result = notificationService.notifyOnBooking(booking);
        assertEquals(1, result);
        verify(notificationRepo).save(any(Notification.class));
    }

    @Test
    void testNotifyOnVenueAdd() {
        when(memberRepo.findById(orgMember.getMemberId())).thenReturn(Optional.of(orgMember));
        int result = notificationService.notifyOnVenueAdd(venue);
        assertEquals(1, result);
        verify(notificationRepo).save(any(Notification.class));
    }

    @Test
    void testNotifyOnPayment() {
        when(bookingService.bookingDetail(1001)).thenReturn(detail);
        when(venueRepo.findById(10)).thenReturn(Optional.of(venue));
        when(memberRepo.findById(venue.getMemberId())).thenReturn(Optional.of(orgMember));

        int result = notificationService.notifyOnPayment(1001);
        assertEquals(1, result);
        verify(notificationRepo, times(2)).save(any(Notification.class)); // user + organizer
    }

    @Test
    void testGetNotifications() {
        when(notificationRepo.findByMemberId(1)).thenReturn(List.of(new Notification()));
        List<Notification> list = notificationService.getNotifications(1);
        assertEquals(1, list.size());
    }

    @Test
    void testDeleteNotification() {
        doNothing().when(notificationRepo).deleteById(42);
        int result = notificationService.deleteNotification(42);
        assertEquals(1, result);
        verify(notificationRepo).deleteById(42);
    }
}
