package com.management.Event.service;

import com.management.Event.model.FoodItem;
import com.management.Event.repositories.FoodItemRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FoodItemServiceImplTest {

    @Mock
    private FoodItemRepo foodItemRepo;

    @InjectMocks
    private FoodItemServiceImpl foodItemService;

    private FoodItem sampleItem;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        sampleItem = new FoodItem(1, "Paneer Tikka", 250, 101);
    }

    @Test
    void testGetFoodItemsByVenueId() {
        when(foodItemRepo.findByVenueId(101)).thenReturn(List.of(sampleItem));

        List<FoodItem> items = foodItemService.getFoodItemsByVenueId(101);

        assertEquals(1, items.size());
        assertEquals("Paneer Tikka", items.get(0).getFoodItemName());
    }

    @Test
    void testAddFoodItem() {
        when(foodItemRepo.save(sampleItem)).thenReturn(sampleItem);

        FoodItem result = foodItemService.addFoodItem(sampleItem);

        assertEquals(250, result.getFoodItemCost());
        assertEquals("Paneer Tikka", result.getFoodItemName());
    }

    @Test
    void testGetFoodItem() {
        when(foodItemRepo.findById(1)).thenReturn(Optional.of(sampleItem));

        FoodItem result = foodItemService.getFoodItem(1);

        assertEquals(101, result.getVenueId());
        assertEquals("Paneer Tikka", result.getFoodItemName());
    }

    @Test
    void testUpdateFoodItem() {
        FoodItem updated = new FoodItem(1, "Veg Biryani", 300, 102);

        when(foodItemRepo.findById(1)).thenReturn(Optional.of(sampleItem));
        when(foodItemRepo.save(any(FoodItem.class))).thenReturn(updated);

        int result = foodItemService.updateFoodItem(updated);

        assertEquals(1, result);
        verify(foodItemRepo).save(any(FoodItem.class));
    }

    @Test
    void testDeleteFoodItem() {
        doNothing().when(foodItemRepo).deleteById(1);

        int result = foodItemService.deleteFoodItem(1);

        assertEquals(1, result);
        verify(foodItemRepo).deleteById(1);
    }
}
