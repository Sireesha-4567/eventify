import { Component } from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-feedback',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent {
  feedback = {
    userName: '',
    eventName: '',
    comments: '',
    rating: ''
  };
  ratings = [1, 2, 3, 4, 5];
  submitted = false;

  onSubmit() {
    this.submitted = true;
    // Here you can handle the feedback submission, e.g., send to backend
    // Reset form if needed
    // this.feedback = { userName: '', eventName: '', comments: '', rating: '' };
  }
}
