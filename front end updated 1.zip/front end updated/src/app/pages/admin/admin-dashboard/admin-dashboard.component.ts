import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SidebarAdminComponent } from '../../../components/sidebar-admin/sidebar-admin.component';
import { Navbar2Component } from '../../../components/navbar2/navbar2.component';

@Component({
  selector: 'app-admin-dashboard',  
  imports: [SidebarAdminComponent,Navbar2Component,RouterModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
